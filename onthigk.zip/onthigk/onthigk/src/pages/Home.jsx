import React from 'react'
import { Container , Image , Card, CardBody } from 'react-bootstrap'
import MenuList from '../components/MenuList'
import { menuList } from '../data/menu'
function Home() {
  return (
    <Container>
        <Image src="/src/img/download1.jfif" style={{width : "1000px"}} />
        <div>
            <h1>Chào mừng đến với nhà hàng ABC</h1>
            <h4>Đây là nơi bạn có thể tìm các món ăn ngon với mức giá rẻ rề</h4>
          
        <MenuList items={menuList}/>
        </div>
    </Container>
  )
}

export default Home