import React from 'react'
import { Container } from 'react-bootstrap'

function Contact() {
  return (
    <Container>
      <h2>
        Liên hệ
      </h2>
      <p>
        Địa chỉ : 123321, Quận 1, Tp.HCM
      </p>
      <p>
        Số điện thoại : 0812321321
      </p>
      <p>Email: contact@gmail.com</p>
    </Container>
  )
}

export default Contact