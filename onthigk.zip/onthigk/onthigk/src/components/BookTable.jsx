import React, { useState } from 'react'
import { Button, Container , Form } from 'react-bootstrap'

function BookTable() {

  const [formData, setFromData] = useState({
    name : '',
    phone : '',
    time : '',
    date : '',
    guests : 1
  });

  const handleChange = (e) => {
    setFromData({
      ...formData,
      [e.target.name]: e.target.value
    });
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Thông tin đặt bàn: ' , formData);
    alert('Đặt bàn thành công!')
    setFromData({
      name : '',
      phone : '',
      time : '',
      date : '',
      guests : 1
    });
  }

  return (
    <>
        <Container>
        <h2>Đặt bàn</h2>
        <Form onSubmit= {handleSubmit}>
          <Form.Group className="mb-3" >
            <Form.Label>Họ Tên</Form.Label>
            <Form.Control 
              
            />
          </Form.Group>
          <Form.Group className="mb-3" >
            <Form.Label>Số điện thoại</Form.Label>
            <Form.Control 
              
            />
          </Form.Group>
          <Button type='submit' >
            Đặt bàn
          </Button>
        </Form>
        </Container>

    </>
  )
}

export default BookTable