import React from 'react'
import { Container } from 'react-bootstrap'

function Footer() {
  return (
    <div style={{height : "100px" , backgroundColor : "#db4444"}}>
        <Container>
            <div style={{alignItems : "center"}} className='mt-5'>
                <div>Họ tên : Trương Gia Huy</div>
                <div>Lớp : DHKTPM18CTT</div>
                <div>MSSV : 22698251</div>
            </div>
        </Container>
    </div>
  )
}

export default Footer