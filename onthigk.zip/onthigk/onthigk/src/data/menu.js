export const menuList = [
    {
        "id" : 1 ,
        "name" : "Phở bò",
        "price" : 50000,
        "description" : "Phở bò truyền thống",
        "image" : "/src/img/download1.jfif"
    },
    {
        "id" : 2 ,
        "name" : "Cơm tấm",
        "price" : 150000,
        "description" : "Cơm tấm giá rẻ",
        "image" : "/src/img/download.jfif"
    },
    {
        "id" : 3 ,
        "name" : "Cơm gà",
        "price" : 20000,
        "description" : "Cơm gà truyền thống",
        "image" : "/src/img/download3.jfif"
    },
    {
        "id" : 4 ,
        "name" : "Hủ tiếu",
        "price" : 30000,
        "description" : "Hủ tiếu truyền thống",
        "image" : "/src/img/download4.jfif"
    },
    {
        "id" : 5 ,
        "name" : "Phở bò",
        "price" : 50000,
        "description" : "Phở bò truyền thống",
        "image" : "/src/img/images.jfif"
    }
]