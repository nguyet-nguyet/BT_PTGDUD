CounterApp
![image](https://github.com/user-attachments/assets/3398bc4e-651d-4e88-bc9b-2210e5a8e7b3)

